export enum Status {
  WAIT = 0,
  OK = 1,
  BAN = -1,
}

export enum ContactType {
  PHONE = 0,
  QQ = 1,
  WECHAT = 2,
}