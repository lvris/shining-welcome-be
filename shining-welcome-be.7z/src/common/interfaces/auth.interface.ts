export interface IAuth {
  password?: string
}

export interface IToken {
  token: string
}